#include "mbed.h"
#include "PCA9685.h"
#include "quadruped.h"

// конструктор, инициализация i2c, инициализация сервоприводов
Quadruped::Quadruped(PinName sda_pin, PinName scl_pin) : controller(sda_pin, scl_pin) {
    
    controller.begin();
    controller.setPrescale(121); // 20 ms
    controller.frequencyI2C(400000); //400kHz fast I2C comunication
    
    LegPosSet(0, ZERO, MIN90, MIN90);
    LegPosSet(1, ZERO, PLU90, PLU90);
    LegPosSet(2, ZERO, MIN90, MIN90);
    LegPosSet(3, ZERO, PLU90, PLU90);
}

// смена состояний для всех ног. RState - массив (4 эл-та) кодов серв Rot, MEState - Mid и End
void Quadruped::setState (int* RState, int* MEState){
    
    // вычисление конечного целевого положения всех сервоприводов
    // и инкрементов перемещения
    
    float targetPos[4][3]; 
    float increment[4][3];
    
    for (int leg = 0; leg < 4; leg++){
        
        // Rot
        switch (RState[leg]){
            case STR1: if (!(leg%2)) targetPos[leg][0] = MIN45; else targetPos[leg][0] = PLU45; break;
            case STR2: if (!(leg%2)) targetPos[leg][0] = PLU45; else targetPos[leg][0] = MIN45; break;
            case DIAG: targetPos[leg][0] = ZERO; break;
        }
        
        // Mid, End
        switch (MEState[leg]){
            
            case PARK: if (!(leg%2)) { targetPos[leg][1] = MIN90; targetPos[leg][2] = MIN90; } else { targetPos[leg][1] = PLU90; targetPos[leg][2] = PLU90; } break;
            case VERT1: if (!(leg%2)) { targetPos[leg][1] = MIN45; targetPos[leg][2] = MIN45; } else { targetPos[leg][1] = PLU45; targetPos[leg][2] = PLU45; } break;
            case OPEN1: if (!(leg%2)) { targetPos[leg][1] = MIN45; targetPos[leg][2] = ZERO; } else { targetPos[leg][1] = PLU45; targetPos[leg][2] = ZERO; } break;
            case VERT2: { targetPos[leg][1] = ZERO; targetPos[leg][2] = ZERO; } break; 
            case OPEN2: if (!(leg%2)) { targetPos[leg][1] = ZERO; targetPos[leg][2] = PLU45; } else { targetPos[leg][1] = ZERO; targetPos[leg][2] = MIN45; } break;
        }
        
        // инкременты
        for (int increment_num = 0; increment_num < 3; increment_num++) {
            increment[leg][increment_num] = (targetPos[leg][increment_num] - currPos[leg][increment_num]) / STEPS;
        }
         
    }
    
    // непосредственно шевеление ногами
    
    for (int step = 0; step < STEPS; step++){
        for (int leg = 0; leg < 4; leg++){
            for (int servo = 0; servo < 3; servo++){          
                currPos[leg][servo] += increment[leg][servo];
                controller.setPWM(leg*3 + servo, 0, currPos[leg][servo]);
            }
        }
    }
}

// прямое позиционирование ноги - только для инициализации и отладки
void Quadruped::LegPosSet(int Leg, float RPos, float MPos, float EPos){
    
    // позиционирование
    controller.setPWM(Leg*3, 0, RPos);
    controller.setPWM(Leg*3+1, 0, MPos);
    controller.setPWM(Leg*3+2, 0, EPos);
    
    // сохранение текущего положения
    currPos[Leg][0] = RPos;
    currPos[Leg][1] = MPos;
    currPos[Leg][2] = EPos;
}