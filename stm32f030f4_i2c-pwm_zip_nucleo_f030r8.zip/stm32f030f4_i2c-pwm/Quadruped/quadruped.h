#include "mbed.h"
#include "PCA9685.h"

#define MIN90 130 // значение PWM для -90 градусов. 
#define PLU90 490 // +90 градусов

#define ZERO (MIN90+PLU90)/2 // ноль
#define MIN45 (MIN90+PLU90)/4 // -45
#define PLU45 3*(MIN90+PLU90)/4 // +45


//коды макросов ног для сервоприводов Mid и End
#define PARK 0
#define VERT1 1
#define OPEN1 2
#define VERT2 3
#define OPEN2 4

//коды макросов ног для сервоприводов Rot
#define STR1 0
#define DIAG 1
#define STR2 2

#define STEPS 100 //шагов на смену состояния
#define STEPDELAY 0.01 //задежка в с на шаг смены состояния

// Собственно i2c контроллер с подключенными сервами
class Quadruped {
    
public:

    // Создание объекта Platform, на входе пины SDA и SCL
    Quadruped(PinName sda_pin, PinName scl_pin);

    // смена состояний для всех ног. RState - массив (4 эл-та) кодов серв Rot, MEState - Mid и End
    void setState (int* RState, int* MEState); 
    
        
    // Прямое позиционирование ноги - только для инициализации и отладки
    void LegPosSet(int Leg, float RPos, float MPos, float EPos);
    
   
private:
     
    // i2c контроллер
    PCA9685 controller;
    
    float currPos[4][3];

};