#include "mbed.h"
#include "quadruped.h"

Quadruped robot(PA_10, PA_9);

int main() {
 

}